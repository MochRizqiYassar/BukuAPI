<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use \App\Models\Buku;
use App\Http\Requests\StoreBukuRequest;
use App\Http\Resources\BukuResource;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\UpdateBukuRequest;



class BukuController extends Controller
{
    public function index()
    {
        return BukuResource::collection(Buku::all());

    }

    public function store(StoreBukuRequest $request)
{
    $data = $request->validated();

    if ($request->hasFile('gambar')) {
        $data['gambar'] = $request->file('gambar')->store('', 'public');
    }

    $buku = Buku::create($data);

    return new BukuResource($buku);
}

    public function show($id)
    {
        return new BukuResource(Buku::findOrFail($id));
    }

    public function update(UpdateBukuRequest $request, Buku $buku)
{
    $data = $request->validated();


    // Handle file upload jika ada
    if ($request->hasFile('gambar')) {
        // Hapus gambar lama kalau ada (opsional)
        if ($buku->gambar && Storage::disk('public')->exists($buku->gambar)) {
            Storage::disk('public')->delete($buku->gambar);
        }

        $data = $request->file('gambar')->store('', 'public');
        $data['gambar'] = $data;
    }

    $buku->update($data);

    return new BukuResource($buku);
}


    public function destroy($id)
    {
        Buku::destroy($id);
        return response()->json(['message' => 'Data berhasil dihapus']);
    }
}
